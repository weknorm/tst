<?php 
$upload_services[] = 'uptobox.com';
$max_file_size['uptobox.com'] = 51200;
$page_upload['uptobox.com'] = 'uptobox.com.php';  
?>