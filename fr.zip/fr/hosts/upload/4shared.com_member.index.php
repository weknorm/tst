<?php 
$upload_services[] = '4shared.com_member';
$max_file_size['4shared.com_member'] = 2048;
$page_upload['4shared.com_member'] = '4shared.com_member.php';
?>