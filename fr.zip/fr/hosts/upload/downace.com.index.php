<?php
$upload_services[]="downace.com";
$max_file_size["downace.com"]=500;
$page_upload["downace.com"] = "downace.com.php";
?>