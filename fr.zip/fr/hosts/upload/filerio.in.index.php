<?php 
$upload_services[] = 'filerio.in';
$max_file_size['filerio.in'] = 10000;
$page_upload['filerio.in'] = 'filerio.in.php';  
?>