<?php
$upload_services[] = 'brupload.net';
$max_file_size['brupload.net'] = 51200;
$page_upload['brupload.net'] = 'brupload.net.php';  
?>