<?php
$upload_services[]="datei.to";
$max_file_size["datei.to"]=500;
$page_upload["datei.to"] = "datei.to.php";
?>