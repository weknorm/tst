<?php
$upload_services[] = 'katfile.com';
$max_file_size['katfile.com'] = 2048; // Filesize limit (MB)
$page_upload['katfile.com'] = 'katfile.com.php';