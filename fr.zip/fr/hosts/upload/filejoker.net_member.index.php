<?php 
$upload_services[] = 'filejoker.net_member';
$max_file_size['filejoker.net_member'] = 2048;
$page_upload['filejoker.net_member'] = 'filejoker.net_member.php';  
?>