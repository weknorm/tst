<?php
$upload_services[]="uptotal.com";
$max_file_size["uptotal.com"]=1500;
$page_upload["uptotal.com"] = "uptotal.com.php";  
?>