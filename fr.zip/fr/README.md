==> For Support Related Rapidleech Visit - www.rapidleech.com 

==> Last Update - January,2016 

==> Latest Version - Rev.431 

==> Active Contributors - 1

==> Notes
* RAR5 Is Now Supported.

==> Script Information
Rapid Leech is a free server transfer script for use on various popular upload/download sites such as uploaded.net, Rapidgator.net and more than 127 others. The famous Rapidleech script transfers files from Other Filehosting Servers To Your Server via your fast servers connection speed and dumps the file on your server. You may then download these files from your server anytime later.

Rapidleech script has being used by more than 5 million users worldwide and has being installed on more than 2000 servers.
For webmasters, if you have not tried the script before, download and install now and you will see how convenient the script can be. You may also generate income by offering your Rapidleech sites to end-users and earn income from advertising programs. Some webmasters are earning hundreds per day on the advertising program(Google and yahoo Ads) from their Rapidleech sites. Script installation is extremely easy and does not require any database.

For end-users, you may search on our forum for readily available installed scripts on servers worldwide. You may use them but please support these sites by visiting their sponsors or donate in order to keep these sites available.

## Deploy to Heroku

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)
